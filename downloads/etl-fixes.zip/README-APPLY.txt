﻿Windows에서 적용하기

1. ZIP을 임시 폴더에 풀고 etl, docs, tests 폴더의 파일을 현재 프로젝트의
   같은 위치에 복사합니다. README-APPLY.txt와 manifest.json은 안내용입니다.
2. 프로젝트 최상위 폴더에서 기존 가상환경과 DB 접속 환경변수를 사용합니다.
3. PowerShell에서 복구된 시트 하나를 먼저 검증합니다.

.\.venv\Scripts\python.exe -m etl.pipeline "data\raw\KP-M-Q-26-000 FROM START HERE.xlsx" --sheet "quote25-041" --dry-run

4. 검증을 통과하면 --dry-run을 제거하고 --schema marine --init-schema를
   추가해 실제 DB에 적재할 수 있습니다.
5. 남은 보류 자료는 docs/rejected-data.md의 절차대로 검토합니다.

이 ZIP은 작업 공간에서 보완한 코드/문서/테스트 7개입니다.
원본 Excel, 업무 데이터 JSON, DB, 비밀번호는 포함하지 않습니다.
이번 재검증은 DB를 변경하지 않았습니다. 기존 번호는 기본적으로 skip이므로
기존 저장 내용이 달라진 견적은 비교 후 갱신 여부를 결정해야 합니다.
